# MDNN-TSN

This is an implementation combining MDNN (Multi-stream Deep Neural Networks) and [TSN](https://github.com/yjxiong/tsn-pytorch) for RGB-D Egocentric Action Recognition. 


### Environment
The code was tested with Python 3.6.5, PyTorch 0.3.1. 


### Project Structure

```
.
├── main.py  			# program entrance
├── opts.py			# experiment params
├── models.py			# implementation of MDNN-TSN
├── dataset.py		# dataloader
├── transforms.py	# data transforms
├── MyVGG.py			# VGG backend
├── ops				# util functions
└── splits_index		# data index of THU-READ

```


### Citation
Please cite the following paper if you feel MDNN useful to your research


@ARTICLE{MDNN2019TCSVT, 
	author={Y. Tang and Z. Wang and J. Lu and J. Feng and J. Zhou}, 
	journal={IEEE Transactions on Circuits and Systems for Video Technology}, 
	title={Multi-stream Deep Neural Networks for RGB-D Egocentric Action Recognition}, 
	year={2018}, 
	volume={}, 
	number={}, 
	pages={1-1}, 
	doi={10.1109/TCSVT.2018.2875441}, 
	ISSN={1051-8215}, 
	month={},
}

### TODOs
Code for data preparation. 

### Acknowledgement
Thanks [TSN](https://github.com/yjxiong/tsn-pytorch) for releasing their code. 