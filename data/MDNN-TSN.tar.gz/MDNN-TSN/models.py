from torch import nn

from ops.basic_ops import ConsensusModule, Identity
from transforms import *
from torch.nn.init import normal, constant

import MyVGG


class StructLoss(torch.nn.Module):
    def __init__(self):
        super(StructLoss, self).__init__()

    def forward(self, feat):
        x1, x2, x3, x4, x5, x6 = feat

        ll2 = torch.mean(torch.pow(x4 - x5, 2), dim=-1)
        ll3 = torch.mean(torch.pow(x5 - x6, 2), dim=-1)
        ll4 = torch.mean(torch.pow(x6 - x4, 2), dim=-1)

        l2 = torch.norm(torch.log(1 + ll2), 2)
        l3 = torch.norm(torch.log(1 + ll3), 2)
        l4 = torch.norm(torch.log(1 + ll4), 2)

        u = torch.norm(torch.mean(x1 * x4, dim=-1), 2)
        v = torch.norm(torch.mean(x2 * x5, dim=-1), 2)
        w = torch.norm(torch.mean(x3 * x6, dim=-1), 2)
        x = torch.norm(torch.mean(x1 * x2, dim=-1), 2)
        y = torch.norm(torch.mean(x2 * x3, dim=-1), 2)
        z = torch.norm(torch.mean(x3 * x1, dim=-1), 2)

        loss = l2 + l3 + l4 + u + v + w + x + y + z
        return loss


class MDNN_TSN(nn.Module):
    def __init__(self, num_class, num_segments,
                 base_model='vgg16',
                 consensus_type='avg',
                 dropout=0.8,
                 partial_bn=True):
        super(MDNN_TSN, self).__init__()

        # backend models
        self.rgb_model = TSNSub(num_class, num_segments, 'RGB', base_model=base_model,
                           dropout=dropout, partial_bn=partial_bn)
        self.depth_model = TSNSub(num_class, num_segments, 'Depth', base_model=base_model,
                           dropout=dropout, partial_bn=partial_bn)
        self.of_model = TSNSub(num_class, num_segments, 'Flow', base_model=base_model,
                           dropout=dropout, partial_bn=partial_bn)

        # fusion layers
        self.feature_dim = self.of_model.feature_dim
        self.fusion_dim = 2048

        self.fc11 = nn.Sequential(nn.Linear(self.feature_dim, self.fusion_dim),
                                nn.Tanh(),
                                nn.Dropout(0.1))
        self.fc12 = nn.Sequential(nn.Linear(self.feature_dim, self.fusion_dim),
                                nn.Tanh(),
                                nn.Dropout(0.1))
        self.fc21 = nn.Sequential(nn.Linear(self.feature_dim, self.fusion_dim),
                                nn.Tanh(),
                                nn.Dropout(0.1))
        self.fc22 = nn.Sequential(nn.Linear(self.feature_dim, self.fusion_dim),
                                nn.Tanh(),
                                nn.Dropout(0.1))
        self.fc31 = nn.Sequential(nn.Linear(self.feature_dim, self.fusion_dim),
                                nn.Tanh(),
                                nn.Dropout(0.1))
        self.fc32 = nn.Sequential(nn.Linear(self.feature_dim, self.fusion_dim),
                                nn.Tanh(),
                                nn.Dropout(0.1))

        # cls layers
        self.new_fc = nn.Linear(self.fusion_dim, num_class)

        std = 0.001
        normal(self.new_fc.weight, 0, std)
        constant(self.new_fc.bias, 0)

        self.consensus = ConsensusModule(consensus_type)

    def forward(self, rgb_input, depth_input, of_input):
        # feature
        rgb_out = self.rgb_model(rgb_input)
        depth_out = self.depth_model(depth_input)
        of_out = self.of_model(of_input)

        # fusion
        f11 = self.fc11(rgb_out)
        f12 = self.fc12(rgb_out)

        f21 = self.fc21(depth_out)
        f22 = self.fc22(depth_out)

        f31 = self.fc31(of_out)
        f32 = self.fc32(of_out)

        g1 = (f12 + f22 + f32) / 3
        base_out = 0.5 * g1 + 0.1533 * (f11 + f21 + f31)

        # cls
        if self.of_model.dropout > 0:
            # (batch * K, feat_dim) -> (batch * K, class_dim)
            base_out = self.new_fc(base_out)

        if self.of_model.reshape:
            base_out = base_out.view((-1, self.of_model.num_segments) + base_out.size()[1:])

        output = self.consensus(base_out)
        return output.squeeze(1),  (f11, f21, f31, f12, f22, f32)

    def partialBN(self, enable):
        self.rgb_model.partialBN(enable)
        self.depth_model.partialBN(enable)
        self.of_model.partialBN(enable)

    def get_optim_policies(self):
        ret = []

        # ret.extend(self.rgb_model.get_optim_policies())
        # ret.extend(self.depth_model.get_optim_policies())
        # ret.extend(self.of_model.get_optim_policies())

        normal_weight = []
        normal_bias = []

        for m in [self.fc11, self.fc12, self.fc21, self.fc22, self.fc31, self.fc32, self.new_fc]:       #TODO: params
            ps = list(m.parameters())
            normal_weight.append(ps[0])
            if len(ps) == 2:
                normal_bias.append(ps[1])

        ret.extend([
            {'params': normal_weight, 'lr_mult': 1, 'decay_mult': 1,
             'name': "normal_weight"},
            {'params': normal_bias, 'lr_mult': 2, 'decay_mult': 0,
             'name': "normal_bias"},
        ])

        return ret


class TSNSub(nn.Module):
    def __init__(self, num_class, num_segments, modality,
                 base_model='vgg16', new_length=None,
                 dropout=0.8,
                 crop_num=1, partial_bn=True):
        super(TSNSub, self).__init__()

        if modality == 'Depth':
            modality = 'RGB'

        self.modality = modality
        self.num_segments = num_segments
        self.reshape = True
        self.dropout = dropout
        self.crop_num = crop_num

        if new_length is None:
            self.new_length = 1 if modality in ["RGB", "Depth"] else 5
        else:
            self.new_length = new_length

        self._prepare_base_model(base_model)
        self.feature_dim = self._prepare_tsn(num_class)

        if self.modality == 'Flow':
            print("Converting the ImageNet model to a flow init model")
            self.base_model = self._construct_flow_model(self.base_model)
            print("Done. Flow model ready...")

        self._enable_pbn = partial_bn
        if partial_bn:
            self.partialBN(True)

    def _prepare_tsn(self, num_class):
        feature_dim = getattr(self.base_model, self.base_model.last_layer_name).in_features
        setattr(self.base_model, self.base_model.last_layer_name, nn.Dropout(p=self.dropout))
        return feature_dim

    def _prepare_base_model(self, base_model):
        if 'vgg' in base_model:
            self.base_model = getattr(MyVGG, base_model)(True)
            self.base_model.fc = nn.Linear(self.base_model.classifier[6].in_features,
                                           self.base_model.classifier[6].out_features)

            self.base_model.last_layer_name = 'fc'
            self.input_size = 224
            self.input_mean = [0.485, 0.456, 0.406]
            self.input_std = [0.229, 0.224, 0.225]

            if self.modality == 'Flow':
                self.input_mean = [0.5]
                self.input_std = [np.mean(self.input_std)]

        else:
            raise ValueError('Unknown base model: {}'.format(base_model))

    def train(self, mode=True):
        """
        Override the default train() to freeze the BN parameters
        :return:
        """
        super(TSNSub, self).train(mode)
        count = 0
        if self._enable_pbn:
            print("Freezing BatchNorm2D except the first one.")
            for m in self.base_model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    count += 1
                    if count >= (2 if self._enable_pbn else 1):
                        m.eval()

                        # shutdown update in frozen mode
                        m.weight.requires_grad = False
                        m.bias.requires_grad = False

    def partialBN(self, enable):
        self._enable_pbn = enable

    def get_optim_policies(self):
        first_conv_weight = []
        first_conv_bias = []
        normal_weight = []
        normal_bias = []
        bn = []

        conv_cnt = 0
        bn_cnt = 0
        for m in self.modules():
            if isinstance(m, torch.nn.Conv2d) or isinstance(m, torch.nn.Conv1d):
                ps = list(m.parameters())
                conv_cnt += 1
                if conv_cnt == 1:
                    first_conv_weight.append(ps[0])
                    if len(ps) == 2:
                        first_conv_bias.append(ps[1])
                else:
                    normal_weight.append(ps[0])
                    if len(ps) == 2:
                        normal_bias.append(ps[1])
            elif isinstance(m, torch.nn.Linear):
                ps = list(m.parameters())
                normal_weight.append(ps[0])
                if len(ps) == 2:
                    normal_bias.append(ps[1])
                  
            elif isinstance(m, torch.nn.BatchNorm1d):
                bn.extend(list(m.parameters()))
            elif isinstance(m, torch.nn.BatchNorm2d):
                bn_cnt += 1
                # later BN's are frozen
                if not self._enable_pbn or bn_cnt == 1:
                    bn.extend(list(m.parameters()))
            elif len(m._modules) == 0:
                if len(list(m.parameters())) > 0:
                    raise ValueError("New atomic module type: {}. Need to give it a learning policy".format(type(m)))

        return [
            {'params': first_conv_weight, 'lr_mult': 5 if self.modality == 'Flow' else 1, 'decay_mult': 1,
             'name': "first_conv_weight"},
            {'params': first_conv_bias, 'lr_mult': 10 if self.modality == 'Flow' else 2, 'decay_mult': 0,
             'name': "first_conv_bias"},
            {'params': normal_weight, 'lr_mult': 1, 'decay_mult': 1,
             'name': "normal_weight"},
            {'params': normal_bias, 'lr_mult': 2, 'decay_mult': 0,
             'name': "normal_bias"},
            {'params': bn, 'lr_mult': 1, 'decay_mult': 0,
             'name': "BN scale/shift"},
        ]

    def forward(self, input):
        sample_len = (3 if self.modality in ["RGB", "Depth"] else 2) * self.new_length

        # (batch * K, channel * data_length, 224, 224) -> (batch * K, feat_dim)
        base_out = self.base_model(input.view((-1, sample_len) + input.size()[-2:]))

        return base_out

    def _construct_flow_model(self, base_model):
        # modify the convolution layers
        # Torch models are usually defined in a hierarchical way.
        # nn.modules.children() return all sub modules in a DFS manner
        modules = list(self.base_model.modules())
        first_conv_idx = list(filter(lambda x: isinstance(modules[x], nn.Conv2d), list(range(len(modules)))))[0]
        conv_layer = modules[first_conv_idx]
        container = modules[first_conv_idx - 1]

        # modify parameters, assume the first blob contains the convolution kernels
        params = [x.clone() for x in conv_layer.parameters()]
        kernel_size = params[0].size()
        new_kernel_size = kernel_size[:1] + (2 * self.new_length, ) + kernel_size[2:]
        new_kernels = params[0].data.mean(dim=1, keepdim=True).expand(new_kernel_size).contiguous()

        new_conv = nn.Conv2d(2 * self.new_length, conv_layer.out_channels,
                             conv_layer.kernel_size, conv_layer.stride, conv_layer.padding,
                             bias=True if len(params) == 2 else False)
        new_conv.weight.data = new_kernels
        if len(params) == 2:
            new_conv.bias.data = params[1].data # add bias if neccessary
        layer_name = list(container.state_dict().keys())[0][:-7] # remove .weight suffix to get the layer name

        # replace the first convlution layer
        setattr(container, layer_name, new_conv)
        return base_model

    def _construct_diff_model(self, base_model, keep_rgb=False):
        # modify the convolution layers
        # Torch models are usually defined in a hierarchical way.
        # nn.modules.children() return all sub modules in a DFS manner
        modules = list(self.base_model.modules())
        first_conv_idx = filter(lambda x: isinstance(modules[x], nn.Conv2d), list(range(len(modules))))[0]
        conv_layer = modules[first_conv_idx]
        container = modules[first_conv_idx - 1]

        # modify parameters, assume the first blob contains the convolution kernels
        params = [x.clone() for x in conv_layer.parameters()]
        kernel_size = params[0].size()
        if not keep_rgb:
            new_kernel_size = kernel_size[:1] + (3 * self.new_length,) + kernel_size[2:]
            new_kernels = params[0].data.mean(dim=1, keepdim=True).expand(new_kernel_size).contiguous()
        else:
            new_kernel_size = kernel_size[:1] + (3 * self.new_length,) + kernel_size[2:]
            new_kernels = torch.cat((params[0].data, params[0].data.mean(dim=1, keepdim=True).expand(new_kernel_size).contiguous()),
                                    1)
            new_kernel_size = kernel_size[:1] + (3 + 3 * self.new_length,) + kernel_size[2:]

        new_conv = nn.Conv2d(new_kernel_size[1], conv_layer.out_channels,
                             conv_layer.kernel_size, conv_layer.stride, conv_layer.padding,
                             bias=True if len(params) == 2 else False)
        new_conv.weight.data = new_kernels
        if len(params) == 2:
            new_conv.bias.data = params[1].data  # add bias if neccessary
        layer_name = list(container.state_dict().keys())[0][:-7]  # remove .weight suffix to get the layer name

        # replace the first convolution layer
        setattr(container, layer_name, new_conv)
        return base_model

    @property
    def crop_size(self):
        return self.input_size

    @property
    def scale_size(self):
        return self.input_size * 256 // 224

    def get_augmentation(self):
        if self.modality in ['RGB', 'Depth']:
            return torchvision.transforms.Compose([GroupMultiScaleCrop(self.input_size, [1, .875, .75, .66]),
                                                   GroupRandomHorizontalFlip(is_flow=False)])
        elif self.modality == 'Flow':
            return torchvision.transforms.Compose([GroupMultiScaleCrop(self.input_size, [1, .875, .75]),
                                                   GroupRandomHorizontalFlip(is_flow=True)])
