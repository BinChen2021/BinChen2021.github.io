import torch.utils.data as data

from PIL import Image
import os
import os.path
import numpy as np
from numpy.random import randint

class VideoRecord(object):
    def __init__(self, row):
        self._data = row

    @property
    def path(self):
        return self._data[0]

    @property
    def num_frames(self):
        return int(self._data[1])

    @property
    def label(self):
        return int(self._data[2])


class TSNDataSet(data.Dataset):
    def __init__(self, root_path, list_file,
                 num_segments=3, new_length=1,
                 image_tmpl='image_{:04d}.jpg', transform=None,
                 random_shift=True, test_mode=False):

        self.modality = 'Flow'
        self.rgbd_image_tmpl = 'image_{:04d}.jpg'
        self.of_image_tmpl = 'frame{:06d}.jpg'

        self.root_path = root_path
        self.list_file = list_file
        self.num_segments = num_segments
        self.transform = transform
        self.random_shift = random_shift
        self.test_mode = test_mode

        self._parse_list()

    def _load_image(self, directory, idx, modality):
        if modality in ['RGB', 'Depth']:
            if modality == 'RGB':
                directory = directory.replace('/home/disk2/tys/trans/tvl1_flow/u/', '/home/disk2/tys/trans/egothu_RGB/')
            if modality == 'Depth':
                directory = directory.replace('/home/disk2/tys/trans/tvl1_flow/u/', '/home/disk2/tys/trans/egothu_depth/')
                directory = directory.replace('RGB', 'D')
            return [Image.open(os.path.join(directory, self.rgbd_image_tmpl.format(idx))).convert('RGB')]

        elif modality == 'Flow':
            directory_u = directory
            directory_v = directory_u.replace('/u/', '/v/')
            x_img = Image.open(os.path.join(directory_u, self.of_image_tmpl.format(idx))).convert('L')
            y_img = Image.open(os.path.join(directory_v, self.of_image_tmpl.format(idx))).convert('L')

            return [x_img, y_img]

    def _parse_list(self):
        self.video_list = [VideoRecord(x.strip().split(' ')) for x in open(self.list_file)]

    def _sample_indices(self, record, data_length):
        """
        :param record: VideoRecord
        :return: list
        """

        average_duration = (record.num_frames - data_length + 1) // self.num_segments
        if average_duration > 0:
            offsets = np.multiply(list(range(self.num_segments)), average_duration) + randint(average_duration, size=self.num_segments)
        elif record.num_frames > self.num_segments:
            arr = randint(record.num_frames - data_length + 1, size=self.num_segments)
            offsets = np.sort(arr)
        else:
            offsets = np.zeros((self.num_segments,))
        return offsets + 1

    def _get_val_indices(self, record, data_length):
        if record.num_frames > self.num_segments + data_length - 1:
            tick = (record.num_frames - data_length + 1) / float(self.num_segments)
            offsets = np.array([int(tick / 2.0 + tick * x) for x in range(self.num_segments)])
        else:
            offsets = np.zeros((self.num_segments,))
        return offsets + 1

    def _get_test_indices(self, record, data_length):

        tick = (record.num_frames - data_length + 1) / float(self.num_segments)

        offsets = np.array([int(tick / 2.0 + tick * x) for x in range(self.num_segments)])

        return offsets + 1

    def __getitem__(self, index):

        record = self.video_list[index]     # VideoRecord obj

        data_length = 5
        if not self.test_mode:
            segment_indices = self._sample_indices(record, data_length) if self.random_shift else self._get_val_indices(record, data_length)
        else:
            segment_indices = self._get_test_indices(record, data_length)

        rgb = self.get(record, segment_indices, 'RGB')
        depth = self.get(record, segment_indices, 'Depth')
        of = self.get(record, segment_indices, 'Flow')
        label = record.label-1
        return rgb, depth, of, label

    def get(self, record, indices, modality):
        images = list()
        for seg_ind in indices:
            p = int(seg_ind)

            if modality in ['RGB', 'Depth']:
                data_length = 1
            elif modality in 'Flow':
                data_length = 5

            for i in range(data_length):
                seg_imgs = self._load_image(record.path, p, modality)
                images.extend(seg_imgs)
                if p < record.num_frames:
                    p += 1

        process_data = self.transform(images)
        return process_data

    def __len__(self):
        return len(self.video_list)

